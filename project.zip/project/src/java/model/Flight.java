/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author sandj
 */
public class Flight implements DatabaseInfo,Serializable{
    private String flightID;
    private String addFrom;
    private String addTo;
    private String date;
    private String time;
    private int chair;
    private String airlineName;
    private int price;
    private int num;

    public Flight() {
    }
    
    
    
    

    public Flight(String flightID, String addFrom, String addTo, String date, String time, int chair, String airlineName, int price) {
        this.flightID = flightID;
        this.addFrom = addFrom;
        this.addTo = addTo;
        this.date = date;
        this.time = time;
        this.chair = chair;
        this.airlineName = airlineName;
        this.price = price;
    }

    public Flight(String addFrom, String addTo, String date, int num) {
        this.addFrom = addFrom;
        this.addTo = addTo;
        this.date = date;
        this.num = num;
    }
    
    

    public Flight(String flightID) {
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt = con.prepareStatement("Select addfrom,addto,Date,Time,chair,AirlineName,price from Flight where flightID =?");
            stmt.setString(1, flightID);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                this.flightID = flightID;
                this.addFrom = rs.getString(1);
                this.addTo = rs.getString(2);
                this.date = rs.getString(3);
                this.time = rs.getString(4);
                this.chair = rs.getInt(5);
                this.airlineName = rs.getString(6);
                this.price = rs.getInt(7);
            }
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
//    public ArrayList<Flight> getList(){
//        ArrayList<Flight> pl = new ArrayList<>();
//        try {
//            Class.forName(driverName);
//            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
//            PreparedStatement stmt = con.prepareStatement("Select flightID from Flight");
//            ResultSet rs = stmt.executeQuery();
//            while(rs.next()){
//                pl.add(new Flight(rs.getString(1)));
//            }
//            con.close();
//            return pl;
//        } catch (Exception ex) {
//            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return null;
//    }
    
     public ArrayList<Flight> getList(int chairnum, String addFrom, String addTo, String date){
        ArrayList<Flight> pl = new ArrayList<>();
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
                PreparedStatement stmt = con.prepareStatement("Select flightID from Flight where [addFrom] = ? and [addTo] = ? and [date] = ? ");
            stmt.setString(1,addFrom );
            stmt.setString(2,addTo );
            stmt.setString(3,date );
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Flight fl = new Flight(rs.getString(1));
                if ((fl.getChair()-Bill.getBoughtTicket(rs.getString(1)))>=chairnum){
                    pl.add(fl);
                }
            }
            con.close();
            return pl;
        } catch (Exception ex) {
            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
            

    public String getFlightID() {
        return flightID;
    }

    public void setFlightID(String flightID) {
        this.flightID = flightID;
    }


    public String getAddFrom() {
        return addFrom;
    }

    public void setAddFrom(String addfFrom) {
        this.addFrom = addfFrom;
    }

    public String getAddTo() {
        return addTo;
    }

    public void setAddTo(String addTo) {
        this.addTo = addTo;
    }

    

    public int getChair() {
        return chair;
    }

    public void setChair(int chair) {
        this.chair = chair;
    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    
    
    
    
}
