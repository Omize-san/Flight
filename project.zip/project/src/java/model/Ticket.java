/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author sandj
 */
public class Ticket implements Serializable{
    private int billID;
    private int ticketID;
    private String passengerName;
    private String sex;
    private int flightID;

    public Ticket(int billID, int ticketID, String passengerName, String sex, int flightID) {
        this.billID = billID;
        this.ticketID = ticketID;
        this.passengerName = passengerName;
        this.sex = sex;
        this.flightID = flightID;
    }

    public int getBillID() {
        return billID;
    }

    public void setBillID(int billID) {
        this.billID = billID;
    }

    public int getTicketID() {
        return ticketID;
    }

    public void setTicketID(int ticketID) {
        this.ticketID = ticketID;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getFlightID() {
        return flightID;
    }

    public void setFlightID(int flightID) {
        this.flightID = flightID;
    }
    
    
}
