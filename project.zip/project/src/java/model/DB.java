/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import static model.DatabaseInfo.dbURL;
import static model.DatabaseInfo.driverName;
import static model.DatabaseInfo.passDB;
import static model.DatabaseInfo.userDB;

/**
 *
 * @author ASUS
 */
public class DB {
    public boolean checkLoginU(String a, String b){
     try{
         
    Class.forName(driverName);
            Connection conn = DriverManager.getConnection(dbURL, userDB, passDB);
              Statement stmt= conn.createStatement();
              ResultSet rs = stmt.executeQuery("Select* from Customer where cusID = '"+a+"'");
                while(rs.next())
              {          
              if (rs.getString("cusID").equals(a) && rs.getString("pass").equals(b)) {
			return true;     
	}
            }conn.close();
                
        } catch (Exception ex) {
            ex.printStackTrace();
                System.out.println(ex.getMessage());
        }
            return false;  
 }
}
