/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import static model.DatabaseInfo.dbURL;
import static model.DatabaseInfo.driverName;
import static model.DatabaseInfo.passDB;
import static model.DatabaseInfo.userDB;

/**
 *
 * @author sandj
 */
public class Bill implements Serializable{
    private int billID;
    private int cusID;
    private int total;
    private String  date;
    private String payID;
    private int numberTick;

    public Bill() {
    }

    public Bill(int billID, int cusID, int total, String date, String payID, int numberTick) {
        this.billID = billID;
        this.cusID = cusID;
        this.total = total;
        this.date = date;
        this.payID = payID;
        this.numberTick = numberTick;
    }

    public int getNumberTick() {
        return numberTick;
    }

    public void setNumberTick(int numberTick) {
        this.numberTick = numberTick;
    }
    
    public String getPayID() {
        return payID;
    }

    public void setPayID(String payID) {
        this.payID = payID;
    }

    

    public int getBillID() {
        return billID;
    }

    public void setBillID(int billID) {
        this.billID = billID;
    }

    public int getCusID() {
        return cusID;
    }

    public void setCusID(int cusID) {
        this.cusID = cusID;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public static int getBoughtTicket(String flightID){
        int num = 0;
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt = con.prepareStatement("SELECT SUM(numberTicket) FROM Bill WHERE flightID =?");
            stmt.setString(1, flightID);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                num = rs.getInt(1);
            }           
            con.close();
            return num;
        } catch (Exception ex) {
            Logger.getLogger(Flight.class.getName()).log(Level.SEVERE, null, ex);
        }
        return num;
    }
    
    public boolean saveDB(Booking sc) {
        int n[] = null;
        if (sc.bk.size() <= (sc.flight.getChair() - Bill.getBoughtTicket(sc.flight.getFlightID()))) {
            try (Connection con = DriverManager.getConnection(dbURL, userDB, passDB)) {
                con.setAutoCommit(false);
                PreparedStatement stmt = con.prepareStatement("Insert into Bill(cusID,total_money,PayID,flightID,numberTicket) output inserted.billID values (?,?,?,?,?)");
                stmt.setInt(1, sc.cus.getId());
                stmt.setInt(2, sc.flight.getPrice() * sc.bk.size());
                stmt.setString(3, sc.getPayId());
                stmt.setString(4, sc.getFlight().getFlightID());
                stmt.setInt(5, sc.bk.size());
                ResultSet identities = stmt.executeQuery();
                identities.next();
                int oid = identities.getInt(1);
                stmt.close();
                stmt = con.prepareCall("Insert into Ticket(passengerName,sex,billID) values (?,?,?)");
                for (Passenger ticket : sc.bk.values()) {
                    stmt.setString(1, ticket.getPassengerName());
                    stmt.setString(2, ticket.getGender());
                    stmt.setInt(3, oid);
                    stmt.addBatch();
                }
                n = stmt.executeBatch();
                if (n.length == sc.bk.size()) {
                    con.commit();
                    return true;
                } else {
                    con.rollback();
                }
            } catch (Exception ex) {
                Logger.getLogger(Bill.class.getName()).log(Level.SEVERE, null, ex);

            }
        } else {
            return false;
        }
        return false;

    }
    
    
    
    
}
