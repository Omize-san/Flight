/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Admin
 */
public class Customer implements DatabaseInfo,Serializable{
    private String name, phone, gender, email, address, pass;
    private int id;

    public Customer() {
    
    }

    public Customer(String name, String phone, String gender, String email, String address, String pass, int id) {
        this.name = name;
        this.phone = phone;
        this.gender = gender;
        this.email = email;
        this.address = address;
        this.pass = pass;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public static Customer login(String x, String pass){
        Customer cus = null;
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL, userDB, passDB);
            PreparedStatement stmt = con.prepareStatement("Select cusID,sex,address,cusName,Phone,email,pass from Customer where (Phone=? OR email=?) and pass =?");
            stmt.setString(1, x);
            stmt.setString(2, x);
            stmt.setString(3, pass);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int id = rs.getInt(1);
                String sex = rs.getString(2);
                String address = rs.getString(3);
                String name = rs.getString(4);
                String phone = rs.getString(5);
                String email = rs.getString(6);
                String pw = pass;
                cus = new Customer(name, phone, sex, email, address, pw, id);
            }
            con.close();
            return cus;
        } catch (Exception ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public static void addNew(String sex,String address,String cusName,String pass,String Phone,String email) {
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL, userDB, passDB);
            PreparedStatement stmt = con.prepareCall("insert into Customer(sex, address, cusName, pass, Phone, email)values( ?, ? , ? ,? , ? , ?) ");
            stmt.setString(1,sex);
            stmt.setString(2,address);
            stmt.setString(3,cusName);
            stmt.setString(4,pass);
            stmt.setString(5,Phone);
            stmt.setString(6,email);
            
            stmt.execute();
            System.out.println("Successful");
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    
    public static String check(String email,String phone) {
        try {
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL, userDB, passDB);
            PreparedStatement stmt = con.prepareCall("select cusID from Customer where Phone=? or email=? ");
            stmt.setString(1,phone);
            stmt.setString(2,email);
            ResultSet rs = stmt.executeQuery();
            System.out.println("Successful");
            con.close();
            return rs.getString(1);
        } catch (Exception ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }
    
}
