/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Hashtable;

/**
 *
 * @author Admin
 */
public class Booking implements Serializable{
    Customer cus;
    Flight flight;
    Hashtable<Integer,Passenger> bk;
    String payId;

    public Booking(Customer cus, Flight flight, Hashtable<Integer, Passenger> bk, String payId) {
        this.cus = cus;
        this.flight = flight;
        this.bk = bk;
        this.payId = payId;
    }

    public Customer getCus() {
        return cus;
    }

    public void setCus(Customer cus) {
        this.cus = cus;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public Hashtable<Integer, Passenger> getBk() {
        return bk;
    }

    public void setBk(Hashtable<Integer, Passenger> bk) {
        this.bk = bk;
    }

    public String getPayId() {
        return payId;
    }

    public void setPayId(String payId) {
        this.payId = payId;
    }

    

    public Booking() {
    }

    
    
    
    
    
}
