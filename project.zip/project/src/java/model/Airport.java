
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author sandj
 */
public class Airport implements DatabaseInfo{
    private String Airport;
    private String AirportName;
    private String Country;
    private String City;

    public Airport() {
    }
    
    

    public Airport(String Airport, String AirportName, String Country, String City) {
        this.Airport = Airport;
        this.AirportName = AirportName;
        this.Country = Country;
        this.City = City;
    }

    public String getAirport() {
        return Airport;
    }

    public void setAirport(String Airport) {
        this.Airport = Airport;
    }

    public String getAirportName() {
        return AirportName;
    }

    public void setAirportName(String AirportName) {
        this.AirportName = AirportName;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }
    
    public Airport(String AirportID){
         try{Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt = con.prepareStatement("Select AirportName,Country,City from Airport where AirportID =?");
            stmt.setString(1, AirportID);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
               this.Airport = AirportID;
               this.AirportName = rs.getString(1);
                this.Country = rs.getString(2);
                this.City = rs.getString(3);
            }
            con.close();
        } catch (Exception ex) {
          Logger.getLogger(Airport.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    
    public ArrayList<Airport> getlist(){
        ArrayList<Airport> ap = new ArrayList<>();
        try{
            Class.forName(driverName);
            Connection con = DriverManager.getConnection(dbURL,userDB,passDB);
            PreparedStatement stmt = con.prepareStatement("Select AirportID from Airport");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                ap.add(new Airport(rs.getString(1)));
            }
            con.close();
            return ap;
        } catch (Exception ex) {
            Logger.getLogger(Airport.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
