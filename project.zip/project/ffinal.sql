CREATE table Payment(
PayID int primary key,
method nvarchar(30) )



Create table Flight (
flightID varchar(20) primary key,
addfrom nvarchar(30),
addto nvarchar(30),
Date date,
Time time,
chair int,
AirlineName nvarchar(30),
price int )


CREATE table Customer (
cusID int identity(1,1) primary key,
sex nvarchar(10),
address nvarchar(30),
cusName nvarchar(30),
Phone varchar(20),
email varchar(30),
pass VARCHAR(50)
) 


Create table Bill(
billID int identity(1,1) primary key,
cusID int,
total_money money,
flightID varchar(20),
bookingDate date default(GETDATE()),
numberTicket int,
PayID int)

Create table Ticket(
ticketID int identity(1,1) primary key,
passengerName nvarchar(30),
sex nvarchar(10),
billID int,
)


CREATE table Airport (
AirportID nvarchar(30) primary key,
AirportName nvarchar(30),
Country nvarchar(30),
City nvarchar(30) )
